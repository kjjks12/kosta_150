/**
������
01-25
*/
public class Services2 
{
	public static void main(String[] args) 
	{
	ArithmeticOperation ao= new ArithmeticOperation();
	ao.printAll(2,5,"+");
	ao.printAll(2,5,"-");
	ao.printAll(2,5,"*");
	ao.printAll(2,5,"/");
	ao.printAll(2,5,"%");

	}
}
